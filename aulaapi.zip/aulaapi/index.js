require("dotenv").config();

const express = require ("express");
const app = express();

app.get("/clientes", (request, response) =>{
    response.json(db.retornaCliente());
})

app.get("/", (request, response) =>{
    response.json({
        message:"Oi!!"
    })
});

app.listen(process.env.PORT, () =>{
    console.log("APP IS RUNNING");
} );