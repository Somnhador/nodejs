const clientes = [
    {
        nome: "Janaina",
        profissao: "Desenvolvedora",
        altura: 1.5
    }
];

function retornaCliente(){
    return clientes;
};

module.exports = {
    retornaCliente
};